package com.example1.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example1.project.entity.MallAdmin;
import com.example1.project.service.MallAdminService;

@RestController
public class MallAdminController {

    @Autowired
    private MallAdminService mallAdminService;

    // Add MallAdmin
    @PostMapping("/addMallAdmin")
    public MallAdmin addMallAdmin(@RequestBody MallAdmin admin) {
        return mallAdminService.addMallAdmin(admin);
    }

    // Get all MallAdmins
    @GetMapping("/getMallAdmins")
    public List<MallAdmin> getAllMallAdmins() {
        return mallAdminService.getAllMallAdmins();
    }

    // Delete MallAdmin by ID
    @DeleteMapping("/deleteMallAdmin/{id}")
    public ResponseEntity<String> deleteMallAdmin(@PathVariable("id") Long id) {
        if (mallAdminService.existsById(id)) {
            mallAdminService.deleteMallAdmin(id);
            return ResponseEntity.ok("MallAdmin with ID " + id + " deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("MallAdmin with ID " + id + " not found.");
        }
    }

    // Update MallAdmin
    @PutMapping("/updateMallAdmin")
    public ResponseEntity<?> updateMallAdmin(@RequestBody MallAdmin admin) {
        if (mallAdminService.existsById(admin.getId())) {
            MallAdmin updatedAdmin = mallAdminService.updateMallAdmin(admin);
            return ResponseEntity.ok(updatedAdmin);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("MallAdmin with ID " + admin.getId() + " not found.");
        }
    }
}