package com.example1.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example1.project.entity.MallAdmin;
import com.example1.project.repository.MallAdminRepo;

@Service
public class MallAdminService {

    @Autowired
    private MallAdminRepo mallAdminRepo;

    // Add a new MallAdmin
    public MallAdmin addMallAdmin(MallAdmin admin) {
        return mallAdminRepo.save(admin);
    }

    // Get all MallAdmins
    public List<MallAdmin> getAllMallAdmins() {
        return mallAdminRepo.findAll();
    }

    // Delete MallAdmin by ID
    public void deleteMallAdmin(long id) {
        mallAdminRepo.deleteById(id);
    }

    // Update MallAdmin
    public MallAdmin updateMallAdmin(MallAdmin admin) {
        MallAdmin existingAdmin = mallAdminRepo.findById(admin.getId()).orElse(null);
        if (existingAdmin != null) {
            existingAdmin.setUsername(admin.getUsername());
            existingAdmin.setEmail(admin.getEmail());
            existingAdmin.setPhone(admin.getPhone());
            existingAdmin.setPassword(admin.getPassword());
            return mallAdminRepo.save(existingAdmin);
        }
        return null; // or throw exception if admin not found
    }

    // Check if MallAdmin exists
    public boolean existsById(Long id) {
        return mallAdminRepo.existsById(id);
    }
}