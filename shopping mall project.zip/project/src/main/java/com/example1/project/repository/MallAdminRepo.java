package com.example1.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example1.project.entity.MallAdmin;



public interface MallAdminRepo extends JpaRepository<MallAdmin,Long> {
    
}